package com.manoj.training.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCucumberExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCucumberExampleApplication.class, args);
	}

}
